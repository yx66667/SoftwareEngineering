// ==UserScript==
// @name         B站永不变质
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  点进阿b首页直接跳转到番剧页面
// @author       ShiHaonan
// @match        https://www.bilibili.com/
// @grant        none
// @require      https://code.jquery.com/jquery-3.6.0.min.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.onload = function(){
        $(".default-entry")[0].click()
        window.close()
    }
})();